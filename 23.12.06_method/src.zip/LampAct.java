
public class LampAct {

	public static void main(String[] args) {
		Lamp l = new Lamp();
		l.on = false;
		l.print();
		l.button();
		l.print();
		l.button();
	}

}
