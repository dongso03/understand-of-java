// 입는 패딩 모델명: String
// 실제 가격: int
// 할인중 : boolean
// 할인율 : int

// 구입시 가격을 반환 하는 메소드 : int// 소수점 버림
//출력예) 모델명
//실가격
//false
//0
// 가격
public class Padding {
	
	String paddingName;
	String paddingName2;
	int realWon;
	boolean yes;
	int discount;
	
	public void torf() {
		yes = !yes;
	}
	
	
	public void disyes() {
			if (yes) {
				System.out.println("할인됨");
			}else {
				System.out.println("할인x");
			}
	}

}