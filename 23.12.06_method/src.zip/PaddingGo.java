
public class PaddingGo {
	public static void main(String[] args) {
		Padding go = new Padding();

		go.paddingName = "나이키";
		go.paddingName2 = "아디다스";
		go.yes = true;
		go.discount = 20;
		go.realWon = 100000;
		

		System.out.println(go.paddingName);
		go.disyes();
		System.out.println("실가격: " + go.realWon);
		System.out.println("할인율: " + go.discount + "%");
		System.out.println("할인가격: " + (go.realWon * (go.discount / 100)));

		System.out.println(go.paddingName2);
	}
}
