// 자동차 클래스
// 현재속도 :(int)
// 가속 메소드 
// 감속 메소드
public class Car {

	int speed;
	
	
	public void fast(int f) {
	speed += f;
	}
	
	public void slow(int s) {
		speed -= s;
		}
	
	
}
